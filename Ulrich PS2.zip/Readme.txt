Hai,

Thanks for downloading this Code Lyoko rip! If you do use this in ANYWAY shape or form, please credit me, AND The Game Factory for the original model/textures.

~Tomix

NOTE: If you have trouble importing these into Sketchup, use Blender to export them to .3ds. The Textures should then import.

Sorry the model isn't in a T-Bind pose. I'm sorta new to posing and stuff, so i will update this model when i learn how to fix this.